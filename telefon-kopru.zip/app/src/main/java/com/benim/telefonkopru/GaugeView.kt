package com.benim.telefonkopru

import android.content.Context
import android.graphics.*
import android.view.View

/** Ana telefonun pilini gösteren canlı logo: halka pil yüzdesi kadar dolar. */
class GaugeView(ctx: Context) : View(ctx) {
    private var pct = -1
    private var charging = false
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG)
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 7.5f; strokeCap = Paint.Cap.ROUND; color = Color.parseColor("#40FFFFFF")
    }
    private val prog = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 7.5f; strokeCap = Paint.Cap.ROUND
    }
    private val white = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val hole = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#16181D") }
    private val num = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER; textSize = 18f; typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }
    private val arc = RectF(24f, 20f, 84f, 80f)
    private val phone = RectF(45.2f, 35f, 62.8f, 61f)

    fun set(p: Int, chg: Boolean) { pct = p; charging = chg; invalidate() }

    override fun onDraw(c: Canvas) {
        val s = width / 108f
        c.save(); c.scale(s, s)
        bg.shader = LinearGradient(0f, 0f, 108f, 108f, Color.parseColor("#262A33"), Color.parseColor("#0A0B0E"), Shader.TileMode.CLAMP)
        c.drawRoundRect(0f, 0f, 108f, 108f, 26f, 26f, bg)
        c.drawArc(arc, 150f, 240f, false, track)
        if (pct > 0) {
            val low = pct <= 15 && !charging
            prog.color = Color.parseColor(if (low) "#FF5C5C" else "#4ED061")
            c.drawArc(arc, 150f, 240f * pct.coerceAtMost(100) / 100f, false, prog)
        }
        c.drawRoundRect(phone, 5.2f, 5.2f, white)
        c.drawCircle(54f, 40f, 1.8f, hole)
        if (pct >= 0) {
            num.color = if (charging) Color.parseColor("#4ED061") else Color.WHITE
            c.drawText(pct.toString(), 54f, 93f, num)
        }
        c.restore()
    }
}
