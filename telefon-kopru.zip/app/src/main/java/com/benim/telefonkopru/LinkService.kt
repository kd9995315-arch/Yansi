package com.benim.telefonkopru

import android.annotation.SuppressLint
import android.app.Notification
import android.app.Service
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothServerSocket
import android.bluetooth.BluetoothSocket
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.ContactsContract
import android.telecom.TelecomManager
import android.telephony.TelephonyManager
import org.json.JSONObject
import java.io.DataInputStream
import java.io.DataOutputStream
import java.util.UUID
import java.util.concurrent.Semaphore
import java.util.concurrent.TimeUnit

@SuppressLint("MissingPermission")
class LinkService : Service() {
    companion object {
        val APP_UUID: UUID = UUID.fromString("7f0c4a52-3b1e-4c58-9a57-1d2e6b8f0a11")
        private val DELAYS = longArrayOf(3, 5, 10, 20, 30, 60)   // yeniden deneme aralıkları (saniye)

        fun start(ctx: Context) { ctx.startForegroundService(Intent(ctx, LinkService::class.java)) }
        fun stop(ctx: Context) { ctx.startService(Intent(ctx, LinkService::class.java).setAction("stop")) }
    }

    @Volatile private var running = false
    @Volatile private var gen = 0
    @Volatile private var attempt = 0
    @Volatile private var serverSock: BluetoothServerSocket? = null
    @Volatile private var activeSock: BluetoothSocket? = null
    private val wake = Semaphore(0)
    private val handler = Handler(Looper.getMainLooper())

    private var callReceiver: BroadcastReceiver? = null
    private var battReceiver: BroadcastReceiver? = null
    private var btReceiver: BroadcastReceiver? = null

    private var ringing = false
    private var ringSent = false
    private var answered = false
    private var sentNum: String? = null
    private var lastNumber: String? = null

    private var lastPct = -1
    private var lastChg = false
    private var warned15 = false
    private var warned5 = false

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        if (i?.action == "stop") {
            Store.autoStart = false
            stopAll()
            stopSelf()
            return START_NOT_STICKY
        }
        if (!goForeground()) { stopSelf(); return START_NOT_STICKY }
        if (running) return START_STICKY
        if (!Store.configured) { stopSelf(); return START_NOT_STICKY }

        Store.autoStart = true
        val mode = Store.mode
        val addr = Store.addr
        Hub.shareOwn = !Store.receiveOnly
        Hub.rangeAlert = Store.rangeAlert
        Hub.lowBattAlert = Store.lowBattAlert
        Hub.deviceName = Store.deviceName
        Hub.key = Hub.deriveKey(Store.code)

        running = true
        attempt = 0
        Hub.state = 1; Hub.peer = ""; Hub.peerName = ""; Hub.changed()
        registerCalls()
        registerBattery()
        registerBt()

        val myGen = ++gen
        Thread {
            val bt = getSystemService(BluetoothManager::class.java).adapter
            while (running && myGen == gen) {
                try {
                    val sock: BluetoothSocket = if (mode == "listen") {
                        val ss = bt.listenUsingRfcommWithServiceRecord("TelefonKopru", APP_UUID)
                        serverSock = ss
                        try { ss.accept() } finally { ss.close() }
                    } else {
                        bt.cancelDiscovery()
                        bt.getRemoteDevice(addr).createRfcommSocketToServiceRecord(APP_UUID).also { it.connect() }
                    }
                    attempt = 0
                    session(sock)
                } catch (_: Exception) { }
                if (!(running && myGen == gen)) break
                val d = DELAYS[minOf(attempt, DELAYS.size - 1)]
                attempt = attempt + 1
                try { wake.tryAcquire(d, TimeUnit.SECONDS) } catch (_: InterruptedException) { }
            }
        }.start()
        return START_STICKY
    }

    private fun goForeground(): Boolean {
        Notif.channels(this)
        val n = Notification.Builder(this, Notif.CH_STATUS)
            .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
            .setContentTitle("Yansı açık")
            .setContentText("Bildirimler eşleşmiş telefonla paylaşılabilir")
            .setOngoing(true).build()
        return try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE)
            else startForeground(1, n)
            true
        } catch (_: Exception) {
            false
        }
    }

    // ---------- Oturum ----------
    private fun session(sock: BluetoothSocket) {
        if (!running) { try { sock.close() } catch (_: Exception) { }; return }
        activeSock = sock
        val din = DataInputStream(sock.inputStream)
        Hub.out = DataOutputStream(sock.outputStream)
        val btName = sock.remoteDevice.name ?: sock.remoteDevice.address
        Hub.peer = btName; Hub.peerName = ""; Hub.state = 2; Hub.changed()
        Notif.alert(this, "Güvenlik: bağlantı kuruldu", "$btName ile bildirim paylaşımı başladı")
        Hub.send(JSONObject().put("t", "hello").put("dev", Hub.myName()).toString())
        sendBattery(registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)), true)
        Hub.send(JSONObject().put("t", "alert").put("text", "${Hub.myName()} bağlandı, bildirimler paylaşılıyor").toString())
        try {
            while (running) {
                val len = din.readInt()
                if (len < 13 || len > 200_000) break
                val buf = ByteArray(len)
                din.readFully(buf)
                val plain = Hub.decrypt(buf)
                if (plain == null) {
                    Notif.alert(this, "Güvenlik uyarısı", "Çözülemeyen veri geldi (kod yanlış olabilir)")
                    break
                }
                handle(JSONObject(plain))
            }
        } catch (_: Exception) {
        } finally {
            val label = if (Hub.peerName.isNotEmpty()) Hub.peerName else btName
            val lastBatt = Hub.peerBatt
            Hub.out = null
            Hub.peerBatt = -1
            Hub.peerName = ""
            Hub.peer = ""
            Hub.state = if (running) 1 else 0
            Hub.changed()
            Notif.cancelCall(this)
            try { sock.close() } catch (_: Exception) { }
            if (running && Hub.rangeAlert) {
                if (lastBatt in 0..5) Notif.alert(this, "Bağlantı koptu", "$label kapanmış olabilir (son pil %$lastBatt)")
                else Notif.alert(this, "Bağlantı koptu", "$label menzil dışında olabilir. Telefonunu unutma.")
            } else {
                Notif.alert(this, "Güvenlik: bağlantı koptu", "$label ile paylaşım durdu")
            }
        }
    }

    private fun handle(j: JSONObject) {
        when (j.optString("t")) {
            "hello" -> { Hub.peerName = j.optString("dev"); Hub.changed() }
            "alert" -> Notif.alert(this, "Güvenlik: eşleşen cihaz", j.optString("text"))
            "dismiss" -> NotifListener.dismiss(j.optString("id"))
            "batt" -> {
                val pct = j.getInt("pct")
                val chg = j.getBoolean("chg")
                Hub.peerBatt = pct; Hub.peerCharging = chg; Hub.changed()
                checkLowBattery(pct, chg)
            }
            "msg" -> {
                val dev = j.optString("dev")
                val app = j.optString("app")
                val title = j.optString("title")
                val text = j.optString("text")
                Hub.add(Msg(dev, app, title, text))
                Notif.msg(this, app, title, text, dev, j.optString("id"))
            }
            "call" -> handleCall(j)
            "callcmd" -> if (Hub.shareOwn) runCallCommand(j.optString("cmd"))
        }
    }

    // ---------- Gelen arama (ikinci telefon tarafı) ----------
    private fun handleCall(j: JSONObject) {
        val dev = j.optString("dev")
        val num = j.optString("num")
        val name = j.optString("name")
        val who = if (name.isNotEmpty()) name else if (num.isNotEmpty()) num else "Bilinmeyen numara"
        when (j.optString("state")) {
            "ringing" -> Notif.callRinging(this, dev, who)
            "answered" -> {
                Notif.cancelCall(this)
                Notif.info(this, "Arama cevaplandı", if (dev.isEmpty()) who else "$dev • $who")
            }
            "ended" -> Notif.cancelCall(this)
            "missed" -> {
                Notif.cancelCall(this)
                Hub.addMissed(Missed(who, num, System.currentTimeMillis()))
                Notif.alert(this, "Cevapsız arama", if (dev.isEmpty()) who else "$dev • $who")
            }
        }
    }

    // ---------- Arama komutu (ana telefon tarafı) ----------
    private fun runCallCommand(cmd: String) {
        try {
            val tm = getSystemService(TelecomManager::class.java)
            if (cmd == "answer") {
                tm.acceptRingingCall()
            } else if (cmd == "reject" && Build.VERSION.SDK_INT >= 28) {
                tm.endCall()
            }
        } catch (_: Exception) { }
    }

    // ---------- Arama durumu (ana telefon tarafı) ----------
    private fun contactName(num: String?): String? {
        if (num.isNullOrEmpty()) return null
        try {
            val uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(num))
            val cur = contentResolver.query(uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)
            if (cur != null) {
                var name: String? = null
                if (cur.moveToFirst()) name = cur.getString(0)
                cur.close()
                return name
            }
        } catch (_: Exception) { }
        return null
    }

    private fun sendCall(state: String) {
        if (!Hub.shareOwn) return
        val num = lastNumber ?: ""
        Hub.send(
            JSONObject().put("t", "call").put("state", state).put("num", num)
                .put("name", contactName(num) ?: "").put("dev", Hub.myName()).toString()
        )
    }

    private fun sendRing() {
        ringSent = true
        sentNum = lastNumber
        sendCall("ringing")
    }

    private fun registerCalls() {
        if (callReceiver != null) return
        callReceiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                val num = i.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER)
                when (i.getStringExtra(TelephonyManager.EXTRA_STATE)) {
                    TelephonyManager.EXTRA_STATE_RINGING -> {
                        if (!ringing) { ringing = true; ringSent = false; answered = false; sentNum = null; lastNumber = null }
                        if (num != null) lastNumber = num
                        if (!ringSent) {
                            if (num != null) sendRing()
                            else handler.postDelayed({ if (ringing && !ringSent) sendRing() }, 1500)
                        } else if (num != null && sentNum == null) {
                            sendRing()    // numara sonradan geldi, bildirimi güncelle
                        }
                    }
                    TelephonyManager.EXTRA_STATE_OFFHOOK -> {
                        if (ringing && !answered) { answered = true; sendCall("answered") }
                    }
                    TelephonyManager.EXTRA_STATE_IDLE -> {
                        if (ringing) {
                            if (answered) sendCall("ended") else sendCall("missed")
                            ringing = false
                            ringSent = false
                        }
                    }
                }
            }
        }
        reg(callReceiver!!, IntentFilter(TelephonyManager.ACTION_PHONE_STATE_CHANGED))
    }

    // ---------- Pil ----------
    private fun sendBattery(i: Intent?, force: Boolean) {
        if (i == null || !Hub.shareOwn) return
        val lvl = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val sc = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        if (lvl < 0 || sc <= 0) return
        val pct = lvl * 100 / sc
        val st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val chg = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
        if (!force && pct == lastPct && chg == lastChg) return
        lastPct = pct; lastChg = chg
        Hub.send(JSONObject().put("t", "batt").put("pct", pct).put("chg", chg).toString())
    }

    private fun registerBattery() {
        if (battReceiver != null) return
        battReceiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) { sendBattery(i, false) }
        }
        reg(battReceiver!!, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    }

    private fun checkLowBattery(pct: Int, chg: Boolean) {
        if (chg || pct > 20) { warned15 = false; warned5 = false; return }
        if (!Hub.lowBattAlert) return
        val who = if (Hub.peerName.isNotEmpty()) Hub.peerName else "Ana telefon"
        if (pct <= 5 && !warned5) {
            warned5 = true; warned15 = true
            Notif.alert(this, "$who: pil bitmek üzere", "Pil %$pct. Şarja takman gerek.")
        } else if (pct <= 15 && !warned15) {
            warned15 = true
            Notif.alert(this, "$who: pil azaldı", "Pil %$pct")
        }
    }

    // ---------- Bluetooth açılınca hemen yeniden dene ----------
    private fun registerBt() {
        if (btReceiver != null) return
        btReceiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                if (i.getIntExtra(BluetoothAdapter.EXTRA_STATE, -1) == BluetoothAdapter.STATE_ON) {
                    attempt = 0
                    wake.release()
                }
            }
        }
        reg(btReceiver!!, IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED))
    }

    private fun reg(r: BroadcastReceiver, f: IntentFilter) {
        try {
            if (Build.VERSION.SDK_INT >= 33) registerReceiver(r, f, Context.RECEIVER_EXPORTED)
            else registerReceiver(r, f)
        } catch (_: Exception) { }
    }

    private fun unreg(r: BroadcastReceiver?) {
        if (r != null) {
            try { unregisterReceiver(r) } catch (_: Exception) { }
        }
    }

    private fun stopAll() {
        running = false
        gen++
        wake.release()
        try { serverSock?.close() } catch (_: Exception) { }
        try { activeSock?.close() } catch (_: Exception) { }
        unreg(callReceiver); callReceiver = null
        unreg(battReceiver); battReceiver = null
        unreg(btReceiver); btReceiver = null
        Hub.out = null
        Hub.state = 0
        Hub.peer = ""
        Hub.peerName = ""
        Hub.peerBatt = -1
        Notif.cancelCall(this)
        Hub.changed()
    }

    override fun onDestroy() {
        stopAll()
        super.onDestroy()
    }
}
