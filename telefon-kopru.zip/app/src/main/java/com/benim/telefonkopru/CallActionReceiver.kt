package com.benim.telefonkopru

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import org.json.JSONObject

/** Arama bildirimindeki Cevapla / Reddet düğmeleri: komutu ana telefona gönderir. */
class CallActionReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val cmd = i.getStringExtra("cmd") ?: return
        Hub.send(JSONObject().put("t", "callcmd").put("cmd", cmd).toString())
        Notif.cancelCall(c)
    }
}
