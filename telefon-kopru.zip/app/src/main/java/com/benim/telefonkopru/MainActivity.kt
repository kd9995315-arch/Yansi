package com.benim.telefonkopru

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothManager
import android.content.Intent
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@SuppressLint("MissingPermission")
class MainActivity : Activity() {
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private var dark = false
    private var cBg = 0; private var cCard = 0; private var cText = 0; private var cSub = 0
    private var cBlue = 0; private var cBlueTint = 0; private var cDiv = 0
    private var cRed = 0; private var cRedTint = 0; private var cRipple = 0

    private lateinit var nameField: EditText
    private lateinit var code: EditText
    private lateinit var onlyReceive: Switch
    private lateinit var swRange: Switch
    private lateinit var swBatt: Switch
    private lateinit var gauge: GaugeView
    private lateinit var statusDot: View
    private lateinit var statusTitle: TextView
    private lateinit var statusSub: TextView
    private lateinit var autoRow: LinearLayout
    private lateinit var missedCard: LinearLayout
    private lateinit var emptyCard: TextView
    private lateinit var list: ListView
    private val msgAdapter = MsgAdapter()
    private val timeFmt = SimpleDateFormat("HH:mm", Locale.getDefault())
    private val dayFmt = SimpleDateFormat("d MMM HH:mm", Locale.getDefault())

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        requestPermissions(arrayOf(
            "android.permission.BLUETOOTH_CONNECT", "android.permission.POST_NOTIFICATIONS",
            "android.permission.READ_PHONE_STATE", "android.permission.READ_CALL_LOG",
            "android.permission.READ_CONTACTS", "android.permission.ANSWER_PHONE_CALLS"), 1)

        dark = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        initColors()
        Notif.channels(this)
        window.statusBarColor = cBg
        window.navigationBarColor = cBg
        if (!dark) window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR

        val header = buildHeader()
        list = ListView(this).apply {
            setBackgroundColor(cBg)
            divider = null
            dividerHeight = 0
            selector = ColorDrawable(Color.TRANSPARENT)
            clipToPadding = false
            setPadding(0, 0, 0, dp(28))
            addHeaderView(header, null, false)
            adapter = msgAdapter
        }
        setContentView(list)

        // Telefon yeniden başladıysa / servis kapandıysa kayıtlı ayarla kendiliğinden başlat
        if (Store.autoStart && Store.configured && Hub.state == 0) {
            try { LinkService.start(this) } catch (_: Exception) { }
        }
    }

    override fun onResume() {
        super.onResume()
        Hub.onChange = { runOnUiThread { refresh() } }
        Hub.purge()
        refresh()
    }

    override fun onPause() {
        saveSettings()
        Hub.onChange = null
        super.onPause()
    }

    private fun saveSettings() {
        val name = nameField.text.toString().trim()
        Store.deviceName = name
        Store.receiveOnly = onlyReceive.isChecked
        Store.rangeAlert = swRange.isChecked
        Store.lowBattAlert = swBatt.isChecked
        if (code.text.isNotBlank()) Store.code = code.text.toString()
        Hub.deviceName = name
        Hub.rangeAlert = swRange.isChecked
        Hub.lowBattAlert = swBatt.isChecked
        Hub.shareOwn = !onlyReceive.isChecked
    }

    // ---------- Renkler ve yardımcılar ----------
    private fun initColors() {
        cBg = Color.parseColor(if (dark) "#000000" else "#F4F4F6")
        cCard = Color.parseColor(if (dark) "#1C1C1E" else "#FFFFFF")
        cText = Color.parseColor(if (dark) "#F2F2F2" else "#111111")
        cSub = Color.parseColor(if (dark) "#9C9CA3" else "#6B6B70")
        cBlue = Color.parseColor(if (dark) "#5AA2FF" else "#3E91FF")
        cBlueTint = Color.parseColor(if (dark) "#1B2B45" else "#E3EEFF")
        cDiv = Color.parseColor(if (dark) "#2C2C2E" else "#E9E9ED")
        cRed = Color.parseColor(if (dark) "#FF6B6B" else "#E5484D")
        cRedTint = Color.parseColor(if (dark) "#3A1E20" else "#FDE9EA")
        cRipple = Color.parseColor(if (dark) "#33FFFFFF" else "#22000000")
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun dpf(v: Int) = v * resources.displayMetrics.density

    private fun round(color: Int, r: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dpf(r) }

    private fun ripple(color: Int, r: Int): RippleDrawable {
        val mask = GradientDrawable().apply { setColor(Color.WHITE); cornerRadius = dpf(r) }
        return RippleDrawable(ColorStateList.valueOf(cRipple), round(color, r), mask)
    }

    private fun lp(w: Int, h: Int, l: Int = 0, t: Int = 0, r: Int = 0, b: Int = 0) =
        LinearLayout.LayoutParams(w, h).apply { setMargins(l, t, r, b) }

    private fun tv(text: String, size: Float, color: Int, medium: Boolean = false) = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(color)
        if (medium) typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = round(cCard, 26)
        setPadding(dp(20), dp(6), dp(20), dp(6))
        layoutParams = lp(MATCH, WRAP, dp(16), 0, dp(16), dp(12))
    }

    private fun section(t: String) = tv(t, 13.5f, cBlue, true).apply { setPadding(dp(28), dp(14), dp(28), dp(8)) }

    private fun sectionWithAction(t: String, action: String, onClick: () -> Unit): LinearLayout {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(28), dp(14), dp(28), dp(8))
        }
        r.addView(tv(t, 13.5f, cBlue, true).apply { layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f) })
        r.addView(tv(action, 13.5f, cRed, true).apply {
            isClickable = true
            setPadding(dp(12), dp(6), 0, dp(6))
            setOnClickListener { onClick() }
        })
        return r
    }

    private fun divider() = View(this).apply {
        setBackgroundColor(cDiv)
        layoutParams = LinearLayout.LayoutParams(MATCH, 1)
    }

    private fun row(title: String, sub: String, trailing: View?, onClick: (() -> Unit)?): LinearLayout {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(14), 0, dp(14))
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f)
        }
        col.addView(tv(title, 16f, cText, true))
        if (sub.isNotEmpty()) col.addView(tv(sub, 13.5f, cSub).apply { setPadding(0, dp(2), 0, 0) })
        r.addView(col)
        if (trailing != null) r.addView(trailing)
        if (onClick != null) { r.isClickable = true; r.setOnClickListener { onClick() } }
        return r
    }

    private fun pill(label: String, bg: Int, fg: Int, onClick: () -> Unit) = tv(label, 16f, fg, true).apply {
        gravity = Gravity.CENTER
        background = ripple(bg, 28)
        isClickable = true
        setOnClickListener { onClick() }
        layoutParams = lp(MATCH, dp(56), dp(16), 0, dp(16), dp(10))
    }

    private fun mkSwitch(on: Boolean) = Switch(this).apply {
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        thumbTintList = ColorStateList(states, intArrayOf(Color.WHITE, Color.WHITE))
        trackTintList = ColorStateList(states, intArrayOf(cBlue, Color.parseColor(if (dark) "#48484A" else "#C7C7CC")))
        isChecked = on
    }

    private fun field(hint: String, value: String, password: Boolean) = EditText(this).apply {
        this.hint = hint
        setHintTextColor(cSub)
        setTextColor(cText)
        textSize = 16f
        inputType = if (password) InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        else InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        background = null
        setPadding(0, dp(16), 0, dp(16))
        setText(value)
    }

    private fun dialogTheme() = if (dark) AlertDialog.THEME_DEVICE_DEFAULT_DARK else AlertDialog.THEME_DEVICE_DEFAULT_LIGHT

    // ---------- Ekran ----------
    private fun buildHeader(): LinearLayout {
        val header = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(cBg) }

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(28), dp(56), dp(28), dp(22))
        }
        gauge = GaugeView(this).apply { layoutParams = LinearLayout.LayoutParams(dp(112), dp(112)) }
        top.addView(gauge)
        top.addView(tv("Yansı", 32f, cText, true).apply { setPadding(0, dp(18), 0, 0) })
        top.addView(tv("Bildirimler ve arama uyarıları diğer telefonda", 14.5f, cSub).apply { setPadding(0, dp(4), 0, 0) })
        header.addView(top)

        // Durum kartı
        statusDot = View(this).apply { layoutParams = lp(dp(12), dp(12), 0, 0, dp(14), 0) }
        statusTitle = tv("", 17f, cText, true)
        statusSub = tv("", 13.5f, cSub).apply { setPadding(0, dp(2), 0, 0) }
        val sCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        sCol.addView(statusTitle); sCol.addView(statusSub)
        val statusCard = card().apply { setPadding(dp(20), dp(16), dp(20), dp(16)) }
        val sRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        sRow.addView(statusDot); sRow.addView(sCol)
        statusCard.addView(sRow)
        header.addView(statusCard)

        // Bağlantı
        header.addView(section("Bağlantı"))
        nameField = field("Bu telefonun adı (ör. Ana telefon)", Store.deviceName, false)
        code = field("Ortak kod (iki telefonda aynı olmalı)", Store.code, true)
        onlyReceive = mkSwitch(Store.receiveOnly)
        swRange = mkSwitch(Store.rangeAlert)
        swBatt = mkSwitch(Store.lowBattAlert)
        val c1 = card()
        c1.addView(nameField)
        c1.addView(divider())
        c1.addView(code)
        c1.addView(divider())
        c1.addView(row("Sadece alsın", "Bu telefon kendi bildirimlerini göndermez", onlyReceive) { onlyReceive.toggle() })
        header.addView(c1)

        // Uyarılar
        header.addView(section("Uyarılar"))
        val cAlert = card()
        cAlert.addView(row("Menzil uyarısı", "Bağlantı koparsa haber ver", swRange) { swRange.toggle() })
        cAlert.addView(divider())
        cAlert.addView(row("Düşük pil uyarısı", "Karşı telefonun pili %15'in altına inince haber ver", swBatt) { swBatt.toggle() })
        header.addView(cAlert)

        val chevron = { tv("›", 24f, cSub) }

        // Ses ve titreşim
        header.addView(section("Ses ve titreşim"))
        val cSound = card()
        cSound.addView(row("Mesaj bildirimleri", "Ses ve titreşimi seç", chevron()) { channelSettings(Notif.CH_MSG) })
        cSound.addView(divider())
        cSound.addView(row("Arama zili", "Gelen arama sesi ve titreşimi", chevron()) { channelSettings(Notif.CH_CALL) })
        cSound.addView(divider())
        cSound.addView(row("Uyarılar", "Bağlantı, pil ve cevapsız arama", chevron()) { channelSettings(Notif.CH_ALERT) })
        header.addView(cSound)

        // Geçmiş
        header.addView(section("Geçmiş"))
        val cHist = card()
        autoRow = row("Otomatik silme", autoText(), chevron()) { pickAuto() }
        cHist.addView(autoRow)
        header.addView(cHist)

        // Kurulum
        header.addView(section("Kurulum"))
        val c2 = card()
        c2.addView(row("Bildirim erişimi", "Bildirimleri okuyabilmesi için gerekli", chevron()) {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })
        c2.addView(divider())
        c2.addView(row("Pil kullanımı", "Pil ayarını “Sınırsız” yap", chevron()) {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        })
        header.addView(c2)

        // Butonlar
        header.addView(View(this), lp(MATCH, dp(8)))
        header.addView(pill("Bu telefon beklesin", cBlue, Color.WHITE) { start("listen", null) })
        header.addView(pill("Diğer telefona bağlan", cBlueTint, cBlue) { pickDevice() })
        header.addView(pill("Durdur", cRedTint, cRed) {
            Store.autoStart = false
            LinkService.stop(this)
        })

        // Cevapsız aramalar
        header.addView(sectionWithAction("Cevapsız aramalar", "Temizle") { Hub.clearMissed() })
        missedCard = card()
        header.addView(missedCard)

        // Gelen bildirimler
        header.addView(sectionWithAction("Gelen bildirimler", "Tümünü sil") { confirmClear() })
        emptyCard = tv("Henüz bildirim yok", 14.5f, cSub).apply {
            gravity = Gravity.CENTER
            background = round(cCard, 26)
            setPadding(dp(20), dp(30), dp(20), dp(30))
            layoutParams = lp(MATCH, WRAP, dp(16), 0, dp(16), dp(8))
        }
        header.addView(emptyCard)
        return header
    }

    private fun autoText(): String =
        if (Store.autoDays == 0) "Kapalı, mesajlar silinmez" else "${Store.autoDays} günden eski mesajlar silinir"

    private fun refresh() {
        synchronized(Hub.messages) { msgAdapter.items = ArrayList(Hub.messages) }
        msgAdapter.notifyDataSetChanged()
        emptyCard.visibility = if (msgAdapter.items.isEmpty()) View.VISIBLE else View.GONE

        // Cevapsız aramalar
        missedCard.removeAllViews()
        val ml: List<Missed> = synchronized(Hub.missed) { ArrayList(Hub.missed) }
        if (ml.isEmpty()) {
            missedCard.addView(tv("Cevapsız arama yok", 14.5f, cSub).apply { setPadding(0, dp(18), 0, dp(18)) })
        } else {
            var idx = 0
            for (m in ml.take(20)) {
                if (idx > 0) missedCard.addView(divider())
                val t = if (m.count > 1) m.who + "  (" + m.count + ")" else m.who
                missedCard.addView(row(t, dayFmt.format(Date(m.time)), null, null))
                idx++
            }
        }

        // Otomatik silme satırı
        val sub = (autoRow.getChildAt(0) as LinearLayout).getChildAt(1)
        if (sub is TextView) sub.text = autoText()

        // Durum
        val dotColor: Int
        val t: String
        val s: String
        when (Hub.state) {
            2 -> {
                dotColor = Color.parseColor("#2EB872")
                t = "Bağlı"
                val who = if (Hub.peerName.isNotEmpty()) Hub.peerName else Hub.peer
                s = if (Hub.peerBatt >= 0) who + " • Pil %" + Hub.peerBatt + (if (Hub.peerCharging) " (şarjda)" else "") else who
            }
            1 -> { dotColor = Color.parseColor("#F5A524"); t = "Bağlantı bekleniyor"; s = "Diğer telefonla bağlantı kuruluyor" }
            else -> { dotColor = cSub; t = "Kapalı"; s = "Aşağıdaki butonlardan birini seçerek başlat" }
        }
        gauge.set(if (Hub.state == 2) Hub.peerBatt else -1, Hub.peerCharging)
        statusDot.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(dotColor) }
        statusTitle.text = t
        statusSub.text = s
        statusSub.visibility = if (s.isEmpty()) View.GONE else View.VISIBLE
    }

    private inner class MsgAdapter : BaseAdapter() {
        var items: List<Msg> = emptyList()
        override fun getCount() = items.size
        override fun getItem(position: Int): Any = items[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val m = items[position]
            val outer = FrameLayout(this@MainActivity).apply { setPadding(dp(16), dp(4), dp(16), dp(4)) }
            val inner = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                background = round(cCard, 22)
                setPadding(dp(18), dp(14), dp(18), dp(14))
            }
            val topRow = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL }
            val head = if (m.dev.isNotEmpty()) m.app + " • " + m.dev else m.app
            topRow.addView(tv(head, 12.5f, cBlue, true).apply { layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f) })
            topRow.addView(tv(timeFmt.format(Date(m.time)), 12f, cSub))
            inner.addView(topRow)
            if (m.title.isNotEmpty()) inner.addView(tv(m.title, 15.5f, cText, true).apply { setPadding(0, dp(6), 0, 0) })
            if (m.text.isNotEmpty()) inner.addView(tv(m.text, 14.5f, cSub).apply {
                setPadding(0, dp(2), 0, 0); maxLines = 4; ellipsize = TextUtils.TruncateAt.END
            })
            outer.addView(inner)
            return outer
        }
    }

    // ---------- Eylemler ----------
    private fun channelSettings(id: String) {
        startActivity(Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS)
            .putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
            .putExtra(Settings.EXTRA_CHANNEL_ID, id))
    }

    private fun confirmClear() {
        AlertDialog.Builder(this, dialogTheme())
            .setTitle("Tüm mesajlar silinsin mi?")
            .setPositiveButton("Sil") { _, _ -> Hub.clearMessages() }
            .setNegativeButton("Vazgeç", null)
            .show()
    }

    private fun pickAuto() {
        val labels = arrayOf("Kapalı", "1 gün", "7 gün", "15 gün", "30 gün")
        val vals = intArrayOf(0, 1, 7, 15, 30)
        var idx = vals.indexOf(Store.autoDays)
        if (idx < 0) idx = 3
        AlertDialog.Builder(this, dialogTheme())
            .setTitle("Otomatik silme")
            .setSingleChoiceItems(labels, idx) { d, w ->
                Store.autoDays = vals[w]
                Hub.purge()
                refresh()
                d.dismiss()
            }
            .show()
    }

    private fun start(mode: String, addr: String?) {
        if (code.text.isBlank()) { Toast.makeText(this, "Önce ortak kodu yaz", Toast.LENGTH_SHORT).show(); return }
        saveSettings()
        Store.mode = mode
        Store.addr = addr ?: ""
        LinkService.start(this)
        Toast.makeText(this, "Başlatıldı", Toast.LENGTH_SHORT).show()
    }

    private fun pickDevice() {
        val devs = getSystemService(BluetoothManager::class.java).adapter.bondedDevices.toList()
        if (devs.isEmpty()) { Toast.makeText(this, "Önce telefonları Bluetooth ayarlarından eşleştir", Toast.LENGTH_LONG).show(); return }
        AlertDialog.Builder(this, dialogTheme()).setTitle("Cihaz seç")
            .setItems(devs.map { it.name ?: it.address }.toTypedArray()) { _, i -> start("connect", devs[i].address) }
            .show()
    }
}
