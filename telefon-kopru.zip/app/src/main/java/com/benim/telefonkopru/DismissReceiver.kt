package com.benim.telefonkopru

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import org.json.JSONObject

/** Bu telefonda bildirim kaydırılıp silinince, karşı telefondaki asıl bildirimi de sildirir. */
class DismissReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val id = i.getStringExtra("id") ?: return
        Hub.send(JSONObject().put("t", "dismiss").put("id", id).toString())
    }
}
