package com.benim.telefonkopru

import android.app.Application

class YansiApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Hub.init(this)
    }
}
