package com.benim.telefonkopru

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

/** Ana ekran widget'ı: ana telefonun pili ve bağlantı durumu. */
class YansiWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (id in appWidgetIds) appWidgetManager.updateAppWidget(id, build(context))
    }

    companion object {
        fun refresh(ctx: Context) {
            try {
                val mgr = AppWidgetManager.getInstance(ctx)
                val ids = mgr.getAppWidgetIds(ComponentName(ctx, YansiWidget::class.java))
                if (ids.isNotEmpty()) mgr.updateAppWidget(ids, build(ctx))
            } catch (_: Exception) { }
        }

        private fun build(ctx: Context): RemoteViews {
            val v = RemoteViews(ctx.packageName, R.layout.widget_yansi)
            val connected = Hub.state == 2
            val who = if (Hub.peerName.isNotEmpty()) Hub.peerName else if (Hub.peer.isNotEmpty()) Hub.peer else "Yansı"
            val pct = if (connected) Hub.peerBatt else -1
            v.setTextViewText(R.id.w_title, if (connected) who else "Yansı")
            v.setTextViewText(R.id.w_pct, if (pct >= 0) "%" + pct else "—")
            val status = when (Hub.state) {
                2 -> if (Hub.peerCharging) "Bağlı • şarjda" else "Bağlı"
                1 -> "Bağlantı bekleniyor"
                else -> "Kapalı"
            }
            v.setTextViewText(R.id.w_status, status)
            v.setProgressBar(R.id.w_bar, 100, if (pct > 0) pct else 0, false)
            val open = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
            v.setOnClickPendingIntent(R.id.w_root, open)
            return v
        }
    }
}
