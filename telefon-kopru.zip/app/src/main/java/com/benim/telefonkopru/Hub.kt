package com.benim.telefonkopru

import android.content.Context
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject
import java.io.DataOutputStream
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKey
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

class Msg(val dev: String, val app: String, val title: String, val text: String, val time: Long = System.currentTimeMillis())

class Missed(val who: String, val num: String, var time: Long, var count: Int = 1)

object Hub {
    val messages = ArrayList<Msg>()
    val missed = ArrayList<Missed>()
    @Volatile var state = 0            // 0 kapalı, 1 bekliyor, 2 bağlı
    @Volatile var peer = ""            // karşı telefonun Bluetooth adı
    @Volatile var peerName = ""        // karşı telefonun kullanıcı tarafından verilen adı
    @Volatile var rangeAlert = true
    @Volatile var lowBattAlert = true
    @Volatile var peerBatt = -1
    @Volatile var peerCharging = false
    @Volatile var deviceName = ""
    @Volatile var onChange: (() -> Unit)? = null
    @Volatile var out: DataOutputStream? = null
    @Volatile var key: SecretKey? = null
    @Volatile var shareOwn = true      // false: bu telefon sadece alır
    private var appCtx: Context? = null

    fun myName(): String = if (deviceName.isBlank()) Build.MODEL else deviceName.trim()

    fun init(ctx: Context) {
        if (appCtx != null) return
        val c = ctx.applicationContext
        appCtx = c
        Store.init(c)
        deviceName = Store.deviceName
        rangeAlert = Store.rangeAlert
        lowBattAlert = Store.lowBattAlert
        load()
        purge()
    }

    fun changed() {
        onChange?.invoke()
        appCtx?.let { YansiWidget.refresh(it) }
    }

    fun deriveKey(code: String): SecretKey {
        val spec = PBEKeySpec(code.toCharArray(), "telefon-kopru-v1".toByteArray(), 120_000, 256)
        val raw = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        return SecretKeySpec(raw, "AES")
    }

    // ---------- Mesaj geçmişi ----------
    fun add(m: Msg) {
        synchronized(messages) {
            messages.add(0, m)
            while (messages.size > 300) messages.removeAt(messages.size - 1)
        }
        purge()
        saveMsgs()
        changed()
    }

    fun addMissed(m: Missed) {
        synchronized(missed) {
            val ex = missed.firstOrNull { it.num.isNotEmpty() && it.num == m.num }
            if (ex != null) {
                missed.remove(ex)
                ex.count = ex.count + 1
                ex.time = m.time
                missed.add(0, ex)
            } else {
                missed.add(0, m)
            }
            while (missed.size > 100) missed.removeAt(missed.size - 1)
        }
        saveMissed()
        changed()
    }

    fun clearMessages() {
        synchronized(messages) { messages.clear() }
        saveMsgs()
        changed()
    }

    fun clearMissed() {
        synchronized(missed) { missed.clear() }
        saveMissed()
        changed()
    }

    /** Otomatik silme süresi dolan kayıtları siler. */
    fun purge() {
        val days = Store.autoDays
        if (days <= 0) return
        val limit = System.currentTimeMillis() - days * 86_400_000L
        var cm = false
        var cx = false
        synchronized(messages) { cm = messages.removeAll { it.time < limit } }
        synchronized(missed) { cx = missed.removeAll { it.time < limit } }
        if (cm) saveMsgs()
        if (cx) saveMissed()
    }

    private fun saveMsgs() {
        try {
            val a = JSONArray()
            synchronized(messages) {
                for (m in messages) a.put(JSONObject().put("d", m.dev).put("a", m.app).put("t", m.title).put("x", m.text).put("ts", m.time))
            }
            Store.putSecure("hist", a.toString())
        } catch (_: Exception) { }
    }

    private fun saveMissed() {
        try {
            val a = JSONArray()
            synchronized(missed) {
                for (m in missed) a.put(JSONObject().put("w", m.who).put("n", m.num).put("ts", m.time).put("c", m.count))
            }
            Store.putSecure("miss", a.toString())
        } catch (_: Exception) { }
    }

    private fun load() {
        try {
            val s = Store.getSecure("hist")
            if (s != null) {
                val a = JSONArray(s)
                synchronized(messages) {
                    messages.clear()
                    for (i in 0 until a.length()) {
                        val o = a.getJSONObject(i)
                        messages.add(Msg(o.optString("d"), o.optString("a"), o.optString("t"), o.optString("x"), o.optLong("ts")))
                    }
                }
            }
        } catch (_: Exception) { }
        try {
            val s = Store.getSecure("miss")
            if (s != null) {
                val a = JSONArray(s)
                synchronized(missed) {
                    missed.clear()
                    for (i in 0 until a.length()) {
                        val o = a.getJSONObject(i)
                        missed.add(Missed(o.optString("w"), o.optString("n"), o.optLong("ts"), o.optInt("c", 1)))
                    }
                }
            }
        } catch (_: Exception) { }
    }

    // ---------- Şifreli gönderim ----------
    fun send(text: String) {
        Thread {
            try {
                val k = key ?: return@Thread
                val iv = ByteArray(12).also { SecureRandom().nextBytes(it) }
                val c = Cipher.getInstance("AES/GCM/NoPadding")
                c.init(Cipher.ENCRYPT_MODE, k, GCMParameterSpec(128, iv))
                val data = iv + c.doFinal(text.toByteArray())
                synchronized(this) {
                    out?.apply { writeInt(data.size); write(data); flush() }
                }
            } catch (_: Exception) { }
        }.start()
    }

    fun decrypt(data: ByteArray): String? = try {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, data, 0, 12))
        String(c.doFinal(data, 12, data.size - 12))
    } catch (_: Exception) { null }
}
