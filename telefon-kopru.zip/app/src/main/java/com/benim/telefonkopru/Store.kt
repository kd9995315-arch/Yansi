package com.benim.telefonkopru

import android.content.Context
import android.content.SharedPreferences
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Telefonun Android Keystore anahtarıyla şifreleme (kod ve geçmiş bu şekilde saklanır). */
object Vault {
    private const val ALIAS = "yansi_vault_key"

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore")
        ks.load(null)
        val existing = ks.getKey(ALIAS, null)
        if (existing is SecretKey) return existing
        val kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        kg.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256).build()
        )
        return kg.generateKey()
    }

    fun enc(s: String): String {
        return try {
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.ENCRYPT_MODE, key())
            val ct = c.doFinal(s.toByteArray())
            "e:" + Base64.encodeToString(c.iv + ct, Base64.NO_WRAP)
        } catch (_: Exception) {
            "p:" + Base64.encodeToString(s.toByteArray(), Base64.NO_WRAP)
        }
    }

    fun dec(s: String): String? {
        return try {
            if (s.length < 3) return null
            val b = Base64.decode(s.substring(2), Base64.NO_WRAP)
            if (s.startsWith("p:")) {
                String(b)
            } else {
                val c = Cipher.getInstance("AES/GCM/NoPadding")
                c.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, b, 0, 12))
                String(c.doFinal(b, 12, b.size - 12))
            }
        } catch (_: Exception) {
            null
        }
    }
}

/** Kalıcı ayarlar. */
object Store {
    private lateinit var sp: SharedPreferences

    fun init(ctx: Context) { sp = ctx.getSharedPreferences("yansi", Context.MODE_PRIVATE) }

    var code: String
        get() = sp.getString("code", null)?.let { Vault.dec(it) } ?: ""
        set(v) { sp.edit().putString("code", Vault.enc(v)).apply() }

    var mode: String
        get() = sp.getString("mode", "") ?: ""
        set(v) { sp.edit().putString("mode", v).apply() }

    var addr: String
        get() = sp.getString("addr", "") ?: ""
        set(v) { sp.edit().putString("addr", v).apply() }

    var receiveOnly: Boolean
        get() = sp.getBoolean("receiveOnly", false)
        set(v) { sp.edit().putBoolean("receiveOnly", v).apply() }

    var rangeAlert: Boolean
        get() = sp.getBoolean("rangeAlert", true)
        set(v) { sp.edit().putBoolean("rangeAlert", v).apply() }

    var lowBattAlert: Boolean
        get() = sp.getBoolean("lowBattAlert", true)
        set(v) { sp.edit().putBoolean("lowBattAlert", v).apply() }

    var deviceName: String
        get() = sp.getString("deviceName", "") ?: ""
        set(v) { sp.edit().putString("deviceName", v).apply() }

    var autoDays: Int
        get() = sp.getInt("autoDays", 15)
        set(v) { sp.edit().putInt("autoDays", v).apply() }

    var autoStart: Boolean
        get() = sp.getBoolean("autoStart", false)
        set(v) { sp.edit().putBoolean("autoStart", v).apply() }

    val configured: Boolean
        get() = mode.isNotEmpty() && code.isNotEmpty() && (mode == "listen" || addr.isNotEmpty())

    fun getSecure(k: String): String? = sp.getString(k, null)?.let { Vault.dec(it) }

    fun putSecure(k: String, v: String) { sp.edit().putString(k, Vault.enc(v)).apply() }
}
