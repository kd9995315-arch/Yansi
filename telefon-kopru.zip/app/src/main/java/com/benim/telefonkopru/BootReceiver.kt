package com.benim.telefonkopru

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Telefon açılınca veya uygulama güncellenince Yansı kendiliğinden başlar. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action == Intent.ACTION_BOOT_COMPLETED || i.action == Intent.ACTION_MY_PACKAGE_REPLACED) {
            if (Store.autoStart && Store.configured) {
                try { LinkService.start(c) } catch (_: Exception) { }
            }
        }
    }
}
