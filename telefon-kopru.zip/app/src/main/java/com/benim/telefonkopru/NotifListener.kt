package com.benim.telefonkopru

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import org.json.JSONObject

class NotifListener : NotificationListenerService() {
    companion object {
        @Volatile var instance: NotifListener? = null
        fun dismiss(key: String) { try { instance?.cancelNotification(key) } catch (_: Exception) { } }
    }

    override fun onListenerConnected() { instance = this }
    override fun onListenerDisconnected() { if (instance === this) instance = null }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (Hub.out == null || !Hub.shareOwn) return        // bağlantı yoksa hiçbir şey paylaşılmaz
        if (sbn.packageName == packageName || sbn.isOngoing) return
        if (sbn.notification.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        val cat = sbn.notification.category
        if (cat == Notification.CATEGORY_CALL || cat == "missed_call") return   // aramalar ayrı iletilir
        val e = sbn.notification.extras
        val title = e.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
        val text = e.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
        if (title.isEmpty() && text.isEmpty()) return
        val app = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString()
        } catch (_: Exception) { sbn.packageName }
        Hub.send(
            JSONObject().put("t", "msg").put("id", sbn.key).put("dev", Hub.myName())
                .put("app", app).put("title", title).put("text", text).toString()
        )
    }
}
