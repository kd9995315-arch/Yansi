package com.benim.telefonkopru

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Icon
import android.media.AudioAttributes
import android.media.RingtoneManager

/** Tüm bildirimler burada; kategoriler ses ve titreşimi açıkça tanımlıdır. */
object Notif {
    const val CH_STATUS = "status"
    const val CH_MSG = "msg2"
    const val CH_ALERT = "alert2"
    const val CH_CALL = "call2"
    const val CH_INFO = "info2"
    const val CALL_ID = 7001
    private var cnt = 100

    @Synchronized
    private fun next(): Int { cnt++; if (cnt > 6000) cnt = 101; return cnt }

    private fun nm(ctx: Context): NotificationManager = ctx.getSystemService(NotificationManager::class.java)

    private fun open(ctx: Context): PendingIntent =
        PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)

    fun channels(ctx: Context) {
        val m = nm(ctx)
        m.deleteNotificationChannel("msg")
        m.deleteNotificationChannel("alert")
        val nSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        val nAttr = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
        val rSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
        val rAttr = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()

        m.createNotificationChannel(NotificationChannel(CH_STATUS, "Durum", NotificationManager.IMPORTANCE_LOW))

        val msg = NotificationChannel(CH_MSG, "Gelen mesajlar", NotificationManager.IMPORTANCE_HIGH)
        msg.setSound(nSound, nAttr)
        msg.enableVibration(true)
        msg.vibrationPattern = longArrayOf(0, 250, 150, 250)
        m.createNotificationChannel(msg)

        val alert = NotificationChannel(CH_ALERT, "Uyarılar (bağlantı, pil, cevapsız arama)", NotificationManager.IMPORTANCE_HIGH)
        alert.setSound(nSound, nAttr)
        alert.enableVibration(true)
        alert.vibrationPattern = longArrayOf(0, 400, 200, 400)
        m.createNotificationChannel(alert)

        val call = NotificationChannel(CH_CALL, "Gelen aramalar (zil)", NotificationManager.IMPORTANCE_HIGH)
        call.setSound(rSound, rAttr)
        call.enableVibration(true)
        call.vibrationPattern = longArrayOf(0, 800, 600, 800, 600, 800, 600)
        m.createNotificationChannel(call)

        m.createNotificationChannel(NotificationChannel(CH_INFO, "Arama bilgisi", NotificationManager.IMPORTANCE_LOW))
    }

    fun msg(ctx: Context, app: String, title: String, text: String, dev: String, key: String) {
        val id = if (key.isEmpty()) next() else key.hashCode()
        val b = Notification.Builder(ctx, CH_MSG)
            .setSmallIcon(android.R.drawable.stat_notify_chat)
            .setContentTitle(if (title.isEmpty()) app else "$app • $title")
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setContentIntent(open(ctx))
            .setAutoCancel(true)
        if (dev.isNotEmpty()) b.setSubText(dev)
        if (key.isNotEmpty()) {
            b.setDeleteIntent(
                PendingIntent.getBroadcast(
                    ctx, id, Intent(ctx, DismissReceiver::class.java).putExtra("id", key),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
            )
        }
        nm(ctx).notify(id, b.build())
    }

    fun alert(ctx: Context, title: String, text: String) {
        nm(ctx).notify(
            next(),
            Notification.Builder(ctx, CH_ALERT)
                .setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setContentTitle(title).setContentText(text)
                .setContentIntent(open(ctx)).setAutoCancel(true).build()
        )
    }

    fun info(ctx: Context, title: String, text: String) {
        nm(ctx).notify(
            next(),
            Notification.Builder(ctx, CH_INFO)
                .setSmallIcon(android.R.drawable.sym_action_call)
                .setContentTitle(title).setContentText(text)
                .setTimeoutAfter(15000L).setAutoCancel(true).build()
        )
    }

    fun callRinging(ctx: Context, dev: String, who: String) {
        val ans = PendingIntent.getBroadcast(
            ctx, 1, Intent(ctx, CallActionReceiver::class.java).putExtra("cmd", "answer"),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val rej = PendingIntent.getBroadcast(
            ctx, 2, Intent(ctx, CallActionReceiver::class.java).putExtra("cmd", "reject"),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(ctx, CH_CALL)
            .setSmallIcon(android.R.drawable.sym_action_call)
            .setContentTitle("Arama geliyor")
            .setContentText(if (dev.isEmpty()) who else "$dev • $who")
            .setSubText(who)
            .setCategory(Notification.CATEGORY_CALL)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setTimeoutAfter(60000L)
            .setContentIntent(open(ctx))
            .addAction(Notification.Action.Builder(Icon.createWithResource(ctx, android.R.drawable.sym_action_call), "Cevapla", ans).build())
            .addAction(Notification.Action.Builder(Icon.createWithResource(ctx, android.R.drawable.ic_menu_close_clear_cancel), "Reddet", rej).build())
            .build()
        n.flags = n.flags or Notification.FLAG_INSISTENT
        nm(ctx).notify(CALL_ID, n)
    }

    fun cancelCall(ctx: Context) {
        try { nm(ctx).cancel(CALL_ID) } catch (_: Exception) { }
    }
}
